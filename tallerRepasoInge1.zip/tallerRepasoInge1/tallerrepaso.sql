create database votaciones2503816;
use votaciones2503816;

create table curso(
	idCurso int primary key,
    nomCurso varchar(45) not null,
    estadoCu bit not null
);

create table consejo(
	idConsejo int primary key,
    nomConsejo varchar(100) not null,
    estadoCo bit not null
);

create table cargo(
idCargo int primary key,
nomCargo varchar(45) not null,
idConsejoFK int not null,
estadoC bit not null,
foreign key (idConsejoFK) references consejo(idConsejo) on delete cascade
);

create table eleccion(
idEleccion int primary key,
fechaEleccion date not null,
anioEleccion year not null, 
estadoEL bit not null
);

create table genero(
idGenero int primary key,
nomGenero varchar(45) not null,
estadoG bit not null
);

create table jornada(
idJornada int primary key,
nomJornada varchar(45) not null,
estadoJ bit not null
);

create table tipoDocumento(
idTipoDoc int primary key,
nomTipoDoc varchar(45) not null,
estadoTD bit not null
);

create table tipoMiembro(
idTipoMiembro int primary key,
nomTipoMiembro varchar(45) not null,
estadoTM bit not null
);

create table usuario(
idUsuario int primary key,
noDocUsuario int not null,
 idTipoDocFK int not null,
 nombreUsuario varchar(100) not null,
 apellidoUsuario varchar(100) not null,
 idGeneroFK int not null,
 fechaNacUsuario date not null,
 emailUsuario varchar(150) not null,
 passwordUsuario varchar(150) not null,
 fotoUsuario blob null,
 idJornadaFK int not null,
 idTipoMiembroFk int not null,
 idCursoFK int not null,
 estadoU bit not null,
 foreign key (idTipoDocFK) references tipoDocumento(idTipoDoc) on delete cascade,
 foreign key (idGeneroFK) references genero(idGenero) on delete cascade,
 foreign key (idJornadaFK) references jornada(idJornada) on delete cascade,
 foreign key (idTipoMiembroFK) references tipoMiembro(idTipoMiembro) on delete cascade,
 foreign key (idCursoFK) references curso(idCurso) on delete cascade
);

create table postulacionCandidato(
idPostCandidato int primary key,
idUsuarioFK int not null,
idEleccionFK int not null,
idCargoFk int not null,
propuestas text(500) not null,
totalVotos int not null,
estadoCan bit not null,
foreign key (idUsuarioFK) references usuario(idUsuario) on delete cascade,
foreign key (idEleccionFK) references eleccion(idEleccion) on delete cascade,
foreign key (idCargoFK) references cargo(idCargo) on delete cascade
);

create table votacion(
idVotacion int primary key,
horaVotacion time not null,
idUsuarioVotanteFK int not null,
idPostCandidatoFK int not null,
estadoV bit not null,
foreign key (idUsuarioVotanteFK) references usuario(idUsuario) on delete cascade,
foreign key (idPostCandidatoFK) references postulacionCandidato(idPostCandidato) on delete cascade
);

insert into genero (idgenero, nomgenero, estadog) values
(1, 'femenino', 1),
(2, 'masculino', 1);

insert into curso (idcurso, nomcurso, estadocu) values
(1, '901', 1),
(2, '902', 1),
(3, '1001', 1),
(4, '1002', 1),
(5, '1003', 0),
(6, '1101', 1),
(7, '1102', 1),
(8, '1103', 0);

insert into jornada (idjornada, nomjornada, estadoj) values
(1, 'mañana', 1),
(2, 'tarde', 1),
(3, 'noche', 1);

insert into tipodocumento (idtipodoc, nomtipodoc, estadotd) values
(1, 'tarjeta de identidad', 1),
(2, 'cédula ciudadanía', 1),
(3, 'cédula extranjeria', 1),
(4, 'pasaporte', 1),
(5, 'nuip', 0);

insert into tipomiembro (idtipomiembro, nomtipomiembro, estadotm) values
(1, 'estudiante', 1),
(2, 'profesor', 1),
(3, 'acudiente', 1);

insert into consejo (idconsejo, nomconsejo, estadoco) values
(1, 'concejo académico', 1),
(2, 'concejo directivo', 1),
(3, 'concejo convivencia', 1);

insert into cargo (idcargo, nomcargo, idconsejofk, estadoc) values
(1, 'personero', 1, 1),
(2, 'contralor', 1, 1),
(3, 'cabildante', 1, 1);

insert into eleccion (ideleccion, fechaeleccion, anioeleccion, estadoel) values
(1, '2020-04-20', 2020, 1),
(2, '2019-04-15', 2019, 1),
(3, '2019-04-12', 2019, 0),
(4, '2018-04-14', 2018, 1),
(5, '2017-04-12', 2017, 1);

insert into usuario (idusuario, nodocusuario, idtipodocfk, nombreusuario, apellidousuario, idgenerofk, fechanacusuario, emailusuario, passwordusuario, idjornadafk, idtipomiembrofk, idcursofk, estadou) values
(1, 1, 1, 'voto', 'blanco', 2, '0000-00-00', '', '', 1, 1, 3, 1),
(2, 1010123456, 1, 'david santiago', 'lópez mora', 2, '2004-10-11', 'davidlopez456@hotmail.com', 'david2004', 1, 1, 1, 1),
(3, 1010123789, 1, 'laura milena', 'gomez bonilla', 1, '2004-03-17', 'lauragomez@gmail.com', 'gomez2004', 1, 1, 1, 1),
(4, 1010123741, 1, 'diego fernando', 'cañon vargas', 2, '2003-05-20', 'diegocanon@hotmail.com', 'diego2003', 1, 1, 1, 1),
(5, 1010123852, 1, 'tatiana', 'vargas cabrera', 1, '2003-11-28', 'tatacabrera@gmail.com', 'cabrera2003', 1, 1, 3, 1),
(6, 1010123963, 1, 'leydy katherine', 'fernandez rodriguez', 1, '2004-06-28', 'leydy2004@gmail.com', 'leydy2004', 1, 1, 4, 1),
(7, 1010123654, 2, 'mauricio', 'bermudez amaya', 2, '2002-01-26', 'maobermudez@gmail.com', 'amaya2002', 1, 1, 4, 1),
(8, 1010741258, 1, 'andres felipe', 'rodriguez perez', 2, '2004-03-23', 'andyrodriguez@gmail.com', 'arodriguez2004', 1, 1, 3, 1),
(9, 1010236859, 1, 'maria angélica', 'triviño latorre', 1, '2002-02-04', 'angelicatri@gmail.com', 'trivino2002', 1, 1, 3, 1),
(10, 1010236963, 1, 'genaro', 'vasquez rodriguez', 2, '2002-11-14', 'gevasquez@gmail.com', 'vasquez123', 1, 1, 3, 0);

insert into postulacioncandidato (idpostcandidato, idusuariofk, ideleccionfk, idcargofk, propuestas, totalvotos, estadocan) values
(1, 1, 1, 1, 'mejorar entrega refrigerios, alargar descansos', 0, 1),
(2, 5, 1, 1, 'mejorar entrega refrigerios, alargar descansos', 0, 1),
(3, 7, 1, 1, 'mejorar sala de informática, construir piscina', 0, 1);

insert into votacion (idvotacion, horavotacion, idusuariovotantefk, idpostcandidatofk, estadov) values
(1, '12:08:15', 1, 1, 1),
(2, '12:12:35', 2, 3, 1),
(3, '12:14:18', 3, 2, 1),
(4, '12:15:58', 4, 2, 1),
(5, '12:18:02', 5, 3, 1),
(6, '12:24:22', 6, 3, 1),
(7, '12:28:02', 7, 3, 1),
(8, '12:30:14', 8, 2, 1),
(9, '12:40:20', 9, 2, 1),
(10, '12:45:20', 10, 2, 1);

select * from usuario;

/*muestre el nombre del consejo con su cargo asignado y el estado actual*/
select nomConsejo, nomCargo, estadoCo from consejo
inner join cargo
on consejo.idConsejo=cargo.idConsejoFK;

/*Realice una consulta que muestre cada usuario con su jornada, tipo de miembro y curso*/
select nombreUsuario, nomJornada, nomTipoMiembro, nomCurso from Usuario join jornada on usuario.idJornadaFK=jornada.idJornada 
join TipoMiembro on usuario.idTipoMiembroFK=tipoMiembro.idTipoMiembro join curso on usuario.idCursoFK=curso.idCurso;

/*Agregue el campo a la tabla estudiante llamada profesión*/
alter table;

/*Realice una consulta que muestre la cantidad de votos obtenidos por cada candidato en las votaciones registradas*/
select p.idPostCandidato,u.nombreUsuario,u.apellidoUsuario,c.nomCargo, count(v.idVotacion) as cantidadVotos from postulacionCandidato p 
join usuario u on p.idUsuarioFK = u.idUsuario join cargo c on p.idCargoFK = c.idCargo
join votacion v on p.idPostCandidato = v.idPostCandidatoFK
group by p.idPostCandidato, u.nombreUsuario, u.apellidoUsuario, c.nomCargo
order by cantidadVotos DESC;

/*Implemente tres procedimientos almacenados, tres vistas y dos subconsultas*/

/*1. prosedimiento para consultar votos de un candidato*/

delimiter //
create procedure obtenerVotosCandidato(in idpostcandidato int)
begin
    select p.idpostcandidato, u.nombreusuario, u.apellidousuario, c.nomcargo, count(v.idvotacion) as cantidadvotos
    from postulacioncandidato p
    join usuario u on p.idusuariofk = u.idusuario
    join cargo c on p.idcargofk = c.idcargo
    left join votacion v on p.idpostcandidato = v.idpostcandidatofk
    where p.idpostcandidato = idpostcandidato
    group by p.idpostcandidato, u.nombreusuario, u.apellidousuario, c.nomcargo;
end //
delimiter ;

call obtenerVotosCandidato(1);

/* 2. procedimiento para registrar una nueva votación */
delimiter //
create procedure registrarVotacion(in idusuariovotante int, in idpostcandidato int, in horavotacion time)
begin
    insert into votacion (horavotacion, idusuariovotantefk, idpostcandidatofk, estadov)
    values (horavotacion, idusuariovotante, idpostcandidato, 1);
end //
delimiter ;
call registrarVotacion(1, 3, '12:30:00');

/* 3. procedimiento para cambiar el estado de una elección (activa/inactiva) */
delimiter //
create procedure cambiarEstadoEleccion(in idEleccion int, in nuevoestado bit)
begin
    update eleccion set estadoEl = nuevoestado where ideleccion = idEleccion;
end //
delimiter ;

call cambiarEstadoEleccion(1,0);

select * from Eleccion;
/* vistas */

/* 1. vista para obtener información de todos los candidatos con los votos obtenidos */
create view vistaCandidatosConVotos as
select p.idpostcandidato, u.nombreusuario, u.apellidousuario, c.nomcargo, count(v.idvotacion) as cantidadvotos
from postulacioncandidato p
join usuario u on p.idusuariofk = u.idusuario
join cargo c on p.idcargofk = c.idcargo
left join votacion v on p.idpostcandidato = v.idpostcandidatofk
group by p.idpostcandidato, u.nombreusuario, u.apellidousuario, c.nomcargo;

select * from vistaCandidatosConVotos;

/* 2. vista para obtener información sobre los usuarios */
create view vistaUsuarios as
select idusuario, nodocusuario, nombreusuario, apellidousuario, fechanacusuario, emailusuario, estadou
from usuario;

select * from vistaUsuarios;

/* 3. vista para obtener la lista de elecciones activas */
create view vistaEleccionesActivas as
select ideleccion, fechaeleccion, anioeleccion
from eleccion
where estadoel = 1;

select * from vistaEleccionesActivas;
/* subconsultas */

/* 1. subconsulta para obtener la cantidad de votos de un candidato específico */
select nombreusuario, apellidousuario, (select count(*) from votacion where idpostcandidatofk = p.idpostcandidato) as cantidadvotos
from postulacioncandidato p join usuario u on p.idusuariofk = u.idusuario where p.idpostcandidato = 1;

/* 2. subconsulta para obtener los usuarios que no han votado en una elección */
select nombreusuario, apellidousuario
from usuario
where idusuario not in (select distinct idusuariovotantefkfrom votacion 
where idpostcandidatofk in (select idpostcandidato from postulacioncandidato where ideleccionfk = 1));











